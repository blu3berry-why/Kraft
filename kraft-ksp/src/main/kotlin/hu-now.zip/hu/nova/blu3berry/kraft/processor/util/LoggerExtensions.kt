package hu.nova.blu3berry.kraft.processor.util

import com.google.devtools.ksp.processing.KSPLogger
import com.google.devtools.ksp.symbol.KSNode

/**
 * Base error format with code-like block.
 */
private fun KSPLogger.err(message: String, symbol: KSNode) {
    error(
        """
        ----------------------------------------
        AutoMapper KSP Error
        ----------------------------------------
        $message
        ----------------------------------------
        """.trimIndent(),
        symbol
    )
}

fun KSPLogger.annotationTargetError(
    annotationName: String,
    expectedTarget: String,
    actualNode: KSNode
) = err(
    """
    Incorrect use of @$annotationName.

    ✔ Expected annotation target: $expectedTarget
    ✘ Found: ${actualNode::class.simpleName}

    Why this is an error:
    @$annotationName is only valid on $expectedTarget declarations.

    How to fix:
    - Move @$annotationName onto a $expectedTarget.
    - Example:
          @$annotationName(SomeType::class)
          data class MyTarget(...)

    """.trimIndent(),
    actualNode
)

/**
 * Missing required annotation argument
 */
fun KSPLogger.missingAnnotationArgument(
    annotationName: String,
    argName: String,
    symbol: KSNode
) = err(
    """
    Missing required argument '$argName' in @$annotationName.

    ✔ Correct usage:
        @$annotationName($argName = MyClass::class)

    ✘ Found: argument '$argName' was not provided.

    Fix:
    - Provide the missing '$argName' argument.
    """.trimIndent(),
    symbol
)

/**
 * Annotation argument is not a KClass
 */
fun KSPLogger.invalidKClassArgument(
    annotationName: String,
    argName: String,
    actualValue: Any?,
    symbol: KSNode
) = err(
    """
    Invalid @$annotationName argument type for '$argName'.

    ✔ Expected: KClass<*>, e.g. MyType::class
    ✘ Found:    ${actualValue?.let { it::class.simpleName } ?: "null"}

    Fix:
    - Use a class literal like MyType::class
    """.trimIndent(),
    symbol
)

/**
 * A @MapField refers to a property that does not exist
 */
fun KSPLogger.noSuchProperty(
    typeName: String,
    propertyName: String,
    available: List<String>,
    symbol: KSNode
) = err(
    """
    Property '$propertyName' does not exist on type '$typeName'.

    Available properties:
    ${available.joinToString("\n") { " - $it" }}

    Fix:
    - Check the spelling of the property.
    - Update your @MapField or @MapFieldOverride accordingly.
    """.trimIndent(),
    symbol
)

/**
 * Unmapped non-nullable property in target class
 */
fun KSPLogger.unmappedNonNullableProperty(
    targetType: String,
    propertyName: String,
    symbol: KSNode
) = err(
    """
    Property '$propertyName' in target type '$targetType' is non-nullable 
    but no mapping was provided.

    Fix:
    - Add @MapField(other = "sourceName")
    - Or add @MapUsing with a converter
    - Or make '$propertyName' nullable
    """.trimIndent(),
    symbol
)
