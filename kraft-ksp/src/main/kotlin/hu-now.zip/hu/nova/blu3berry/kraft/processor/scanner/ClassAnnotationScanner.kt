package hu.nova.blu3berry.kraft.processor.scanner

import com.google.devtools.ksp.processing.KSPLogger
import com.google.devtools.ksp.processing.Resolver
import com.google.devtools.ksp.symbol.*
import hu.nova.blu3berry.kraft.model.MappingDirection
import hu.nova.blu3berry.kraft.onclass.from.MapFrom
import hu.nova.blu3berry.kraft.onclass.to.MapTo
import hu.nova.blu3berry.kraft.processor.util.annotationTargetError
import hu.nova.blu3berry.kraft.processor.util.findAnnotation
import hu.nova.blu3berry.kraft.processor.util.getKClassArgOrNull

class ClassAnnotationScanner(
    private val resolver: Resolver,
    private val logger: KSPLogger
) {
    companion object {
        const val CLASS = "class"
        const val VALUE = "value"
        val MAP_FROM_FQ = MapFrom::class.qualifiedName!!
        val MAP_TO_FQ = MapTo::class.qualifiedName!!
    }

    fun scan(): List<ClassMappingScanResult> {
        val results = mutableListOf<ClassMappingScanResult>()

        resolver.getSymbolsWithAnnotation(MAP_FROM_FQ).forEach { symbol ->

            if (symbol !is KSClassDeclaration) {
                logger.annotationTargetError(
                    actualNode = symbol,
                    annotationName = MAP_FROM_FQ,
                    expectedTarget = CLASS
                )
                return@forEach
            }

            val ann = symbol.findAnnotation(MAP_FROM_FQ)
                ?: return@forEach

            val sourceType = ann.getKClassArgOrNull(
                name = VALUE,
                logger = logger,
                symbol = symbol,
                annotationFqName = MAP_FROM_FQ
            ) ?: return@forEach

            results += ClassMappingScanResult(
                direction = MappingDirection.FROM,
                sourceType = sourceType.declaration as KSClassDeclaration,
                targetType = symbol,
                annotatedClass = symbol
            )
        }

        // ---- @MapTo ----
        resolver.getSymbolsWithAnnotation(MAP_TO_FQ).forEach { symbol ->

            if (symbol !is KSClassDeclaration) {
                logger.annotationTargetError(
                    actualNode = symbol,
                    annotationName = MAP_TO_FQ,
                    expectedTarget = CLASS
                )
                return@forEach
            }

            val ann = symbol.findAnnotation(MAP_TO_FQ)
                ?: return@forEach

            val targetType = ann.getKClassArgOrNull(
            name = VALUE,
            logger = logger,
            symbol = symbol,
            annotationFqName = MAP_TO_FQ
        ) ?: return@forEach

            results += ClassMappingScanResult(
                direction = MappingDirection.TO,
                sourceType = symbol,
                targetType = targetType.declaration as KSClassDeclaration,
                annotatedClass = symbol
            )
        }

        return results
    }

}
