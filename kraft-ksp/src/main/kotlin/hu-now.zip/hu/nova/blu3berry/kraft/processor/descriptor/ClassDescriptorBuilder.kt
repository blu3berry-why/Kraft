package hu.nova.blu3berry.kraft.processor.descriptor

import com.google.devtools.ksp.getDeclaredProperties
import com.google.devtools.ksp.processing.KSPLogger
import com.google.devtools.ksp.symbol.*
import hu.nova.blu3berry.kraft.model.*
import hu.nova.blu3berry.kraft.processor.scanner.ClassMappingScanResult
import hu.nova.blu3berry.kraft.processor.scanner.ConfigObjectScanResult
import hu.nova.blu3berry.kraft.processor.util.unmappedNonNullableProperty

/**
 * Builds a single [MapperDescriptor] from one class-level mapping declaration:
 *
 *   sourceType -> targetType
 *
 * coming from a single @MapFrom / @MapTo annotated class.
 *
 * Strict behaviour:
 *  - Every primary constructor parameter of the TARGET must have a matching
 *    property in the SOURCE with the same name and the same KSType.
 *  - If no matching property is found → error, returns null.
 *  - If the type does not match exactly → error, returns null.
 *
 * Config objects are accepted but not used here – they represent an
 * alternative way to declare mappers (handled separately).
 */
class ClassDescriptorBuilder(
    private val logger: KSPLogger,
    private val mapping: ClassMappingScanResult,
    @Suppress("UNUSED_PARAMETER")
    private val configObjects: List<ConfigObjectScanResult>
) {

    fun build(): MapperDescriptor? {
        val sourceClass = mapping.sourceType
        val targetClass = mapping.targetType

        // From / To type infos for the descriptor
        val fromTypeInfo = sourceClass.toTypeInfo(sourceClass.asStarProjectedType())
        val toTypeInfo = targetClass.toTypeInfo(targetClass.asStarProjectedType())

        val targetCtor = targetClass.primaryConstructor
        if (targetCtor == null) {
            logger.error(
                "Target type '${targetClass.qualifiedName?.asString() ?: targetClass.simpleName.asString()}' " +
                        "must have a primary constructor for mapping.",
                targetClass
            )
            return null
        }

        // All source properties by name (used for reading)
        val sourcePropertiesByName = sourceClass.toPropertyInfoMap()

        // Target properties in primary-constructor order
        val targetProperties = targetCtor.parameters.mapNotNull { param ->
            val paramName = param.name?.asString()
            if (paramName == null) {
                logger.error(
                    "Found unnamed constructor parameter in '${targetClass.qualifiedName?.asString()}'. " +
                            "This is not supported by the mapper.",
                    param
                )
                return@mapNotNull null
            }

            val targetPropDecl = targetClass
                .getDeclaredProperties()
                .firstOrNull { it.simpleName.asString() == paramName }

            if (targetPropDecl == null) {
                logger.error(
                    "Primary constructor parameter '$paramName' of " +
                            "'${targetClass.qualifiedName?.asString()}' must correspond to a 'val' or 'var' property.",
                    param
                )
                return@mapNotNull null
            }

            val ksType = param.type.resolve()
            val typeDecl = ksType.declaration as? KSClassDeclaration
            if (typeDecl == null) {
                logger.error(
                    "Unsupported type for property '$paramName' in " +
                            "'${targetClass.qualifiedName?.asString()}'. Only class types are supported.",
                    param
                )
                return@mapNotNull null
            }

            val typeInfo = typeDecl.toTypeInfo(ksType)

            PropertyInfo(
                name = paramName,
                type = typeInfo,
                declaration = targetPropDecl,
                hasDefault = param.hasDefault // ✔ correct place to check defaults
            )
        }

        // If we could not materialise all constructor parameters, abort.
        if (targetProperties.size != targetCtor.parameters.size) {
            return null
        }

        val propertyMappings = mutableListOf<PropertyMappingStrategy>()

        for (targetProperty in targetProperties) {
            val targetName = targetProperty.name
            val sourceProperty = sourcePropertiesByName[targetName]

            if (sourceProperty == null) {
                val targetTypeName =
                    targetClass.qualifiedName?.asString() ?: targetClass.simpleName.asString()

                val ksType = targetProperty.type.ksType
                val isNonNullable = ksType.nullability == Nullability.NOT_NULL

                if (isNonNullable && !targetProperty.hasDefault) {
                    logger.unmappedNonNullableProperty(
                        targetType = targetTypeName,
                        propertyName = targetName,
                        symbol = targetProperty.declaration
                    )
                } else {
                    logger.error(
                        "No matching source property found for target property '$targetName' " +
                                "in target type '$targetTypeName'.",
                        targetProperty.declaration
                    )
                }
                return null
            }

            // Strict type check: require exactly the same KSType
            if (sourceProperty.type.ksType != targetProperty.type.ksType) {
                val targetTypeName =
                    targetClass.qualifiedName?.asString() ?: targetClass.simpleName.asString()

                logger.error(
                    "Type mismatch for property '$targetName' in mapping " +
                            "'${sourceClass.qualifiedName?.asString()} -> $targetTypeName'. " +
                            "Source type: '${sourceProperty.type.ksType.declaration.qualifiedName?.asString()}', " +
                            "target type: '${targetProperty.type.ksType.declaration.qualifiedName?.asString()}'.",
                    targetProperty.declaration
                )
                return null
            }

            propertyMappings += PropertyMappingStrategy.Direct(
                targetProperty = targetProperty,
                sourceProperty = sourceProperty
            )
        }

        val mapperId = MapperId(
            fromQualifiedName = sourceClass.qualifiedName?.asString()
                ?: sourceClass.simpleName.asString(),
            toQualifiedName = targetClass.qualifiedName?.asString()
                ?: targetClass.simpleName.asString()
        )

        val mappingSource: MappingSource = MappingSource.ClassAnnotation(
            annotatedClass = mapping.annotatedClass,
            direction = mapping.direction
        )

        return MapperDescriptor(
            id = mapperId,
            fromType = fromTypeInfo,
            toType = toTypeInfo,
            source = mappingSource,
            propertyMappings = propertyMappings
        )
    }

    /**
     * Build a [PropertyInfo] map for all declared properties of this class.
     * Used for reading from the *source* type.
     */
    private fun KSClassDeclaration.toPropertyInfoMap(): Map<String, PropertyInfo> {
        val result = mutableMapOf<String, PropertyInfo>()

        for (prop in getDeclaredProperties()) {
            val name = prop.simpleName.asString()
            val ksType = prop.type.resolve()
            val typeDecl = ksType.declaration as? KSClassDeclaration ?: continue
            val typeInfo = typeDecl.toTypeInfo(ksType)

            result[name] = PropertyInfo(
                name = name,
                type = typeInfo,
                declaration = prop,
                hasDefault = false // source props never use defaults
            )
        }

        return result
    }
}
