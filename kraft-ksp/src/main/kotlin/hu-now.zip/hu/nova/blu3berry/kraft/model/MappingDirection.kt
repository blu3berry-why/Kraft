package hu.nova.blu3berry.kraft.model

enum class MappingDirection {
    FROM, // @MapFrom – annotated class is TARGET
    TO    // @MapTo   – annotated class is SOURCE
}