package hu.nova.blu3berry.kraft.processor.descriptor

import com.google.devtools.ksp.processing.KSPLogger
import com.google.devtools.ksp.symbol.Nullability
import hu.nova.blu3berry.kraft.model.*
import hu.nova.blu3berry.kraft.processor.scanner.ConfigObjectScanResult
import hu.nova.blu3berry.kraft.processor.util.unmappedNonNullableProperty

/**
 * PropertyResolver is the core mapping rule engine.
 *
 * For ONE target property, it determines exactly how it should be mapped:
 *   - Ignored
 *   - Renamed (via override)
 *   - Direct (same name, same type)
 *   - Converted (@MapUsing)       [TODO]
 *   - Nested mapping (type → type)[TODO]
 *   - Collections (List<T>)       [TODO]
 *
 * If the property cannot be mapped and is required → logs an error.
 */
class PropertyResolver(
    private val logger: KSPLogger,
    private val sourceProperties: Map<String, PropertyInfo>,
    private val configMappings: List<ConfigObjectScanResult>,
    private val allDescriptors: Map<MappingKey, MapperDescriptor>
) {

    /**
     * Resolve mapping strategy for one target property.
     *
     * @return a PropertyMappingStrategy OR null if mapping failed (error already logged)
     */
    fun resolve(
        targetProperty: PropertyInfo,
        sourceTypeName: String,
        targetTypeName: String
    ): PropertyMappingStrategy? {

        val targetName = targetProperty.name

        // ----------------------------------------------------------------------
        // 1) IGNORE RULE
        // ----------------------------------------------------------------------
        if (isIgnored(targetName)) {
            return PropertyMappingStrategy.Ignored(targetProperty)
        }

        // ----------------------------------------------------------------------
        // 2) RENAME OVERRIDE RULE
        // ----------------------------------------------------------------------
        val overriddenSourceName = resolveOverride(targetName)
        if (overriddenSourceName != null) {

            val sourceProp = sourceProperties[overriddenSourceName]
            if (sourceProp == null) {
                logger.error(
                    "Mapping override defines '$overriddenSourceName' → '$targetName', " +
                        "but '$overriddenSourceName' does not exist on source type '$sourceTypeName'.",
                    targetProperty.declaration
                )
                return null
            }

            if (!typesMatch(sourceProp, targetProperty)) {
                logger.error(
                    "Override mapping '$overriddenSourceName' → '$targetName' has incompatible types.",
                    targetProperty.declaration
                )
                return null
            }

            return PropertyMappingStrategy.Renamed(
                targetProperty = targetProperty,
                sourceProperty = sourceProp
            )
        }

        // ----------------------------------------------------------------------
        // 3) DIRECT MATCH RULE (same name, same type)
        // ----------------------------------------------------------------------
        val sourceProperty = sourceProperties[targetName]
        if (sourceProperty != null) {
            if (!typesMatch(sourceProperty, targetProperty)) {
                logger.error(
                    "Type mismatch for property '$targetName' in mapping " +
                        "'$sourceTypeName → $targetTypeName'.\n" +
                        "Source type: '${sourceProperty.type.ksType}'\n" +
                        "Target type: '${targetProperty.type.ksType}'",
                    targetProperty.declaration
                )
                return null
            }

            return PropertyMappingStrategy.Direct(
                targetProperty = targetProperty,
                sourceProperty = sourceProperty
            )
        }

        // ----------------------------------------------------------------------
        // 4) CONVERTER RULE (@MapUsing)
        // ----------------------------------------------------------------------
        val converter = findConverterFor(targetProperty)
        if (converter != null) {
            // TODO: type inference + verify source type
            return PropertyMappingStrategy.Converted(
                targetProperty = targetProperty,
                converter = converter,
                sourceProperty = null // TODO: determine which source property the converter consumes
            )
        }

        // ----------------------------------------------------------------------
        // 5) NESTED MAPPING (sourceType → targetType exists)
        // ----------------------------------------------------------------------
        val nestedMapping = findNestedMapping(targetProperty)
        if (nestedMapping != null) {
            return nestedMapping
        }

        // ----------------------------------------------------------------------
        // 6) COLLECTION MAPPING (List<T>, Set<T>, etc.)
        // ----------------------------------------------------------------------
        val collectionMapping = resolveCollection(targetProperty)
        if (collectionMapping != null) {
            return collectionMapping
        }

        // ----------------------------------------------------------------------
        // 7) MISSING MAPPING → throw error if required
        // ----------------------------------------------------------------------
        val isRequired = targetProperty.type.ksType.nullability == Nullability.NOT_NULL &&
                !targetProperty.hasDefault

        if (isRequired) {
            logger.unmappedNonNullableProperty(
                targetType = targetTypeName,
                propertyName = targetName,
                symbol = targetProperty.declaration
            )
        } else {
            logger.error(
                "No mapping found for optional target property '$targetName' " +
                    "in type '$targetTypeName'.",
                targetProperty.declaration
            )
        }

        return null
    }

    // ----------------------------------------------------------------------
    // Helper: ignore
    // ----------------------------------------------------------------------

    private fun isIgnored(targetName: String): Boolean =
        configMappings.any { config ->
            targetName in config.ignoreList
        }

    // ----------------------------------------------------------------------
    // Helper: override rename (StringPair(from, to))
    // ----------------------------------------------------------------------

    private fun resolveOverride(targetName: String): String? {
        for (config in configMappings) {
            for (pair in config.overrides) {
                if (pair.to == targetName) return pair.from
            }
        }
        return null
    }

    // ----------------------------------------------------------------------
    // Helper: type equality (strict for now)
    // ----------------------------------------------------------------------

    private fun typesMatch(source: PropertyInfo, target: PropertyInfo): Boolean =
        source.type.ksType == target.type.ksType

    // ----------------------------------------------------------------------
    // Helper: converter resolution (@MapUsing)
    // ----------------------------------------------------------------------

    private fun findConverterFor(targetProperty: PropertyInfo): ConverterInfo? {
        for (config in configMappings) {
            for (c in config.converters) {
                // TODO: improve parameter matching
                if (c.targetKSType == targetProperty.type.ksType) {
                    return c
                }
            }
        }
        return null
    }

    // ----------------------------------------------------------------------
    // Helper: nested mapping (type → type)
    // ----------------------------------------------------------------------

    private fun findNestedMapping(targetProperty: PropertyInfo): PropertyMappingStrategy.NestedMapper? {

        val targetType = targetProperty.type.ksType.declaration

        for ((key, descriptor) in allDescriptors) {
            val toDecl = key.to.declaration
            if (toDecl == targetType) {
                return PropertyMappingStrategy.Nested(
                    targetProperty = targetProperty,
                    nestedDescriptor = descriptor
                )
            }
        }

        return null
    }

    // ----------------------------------------------------------------------
    // Helper: collection/list mapping
    // ----------------------------------------------------------------------

    private fun resolveCollection(targetProperty: PropertyInfo): PropertyMappingStrategy.CollectionMapped? {
        // TODO: Implement list/collection logic with element resolver
        return null
    }
}
